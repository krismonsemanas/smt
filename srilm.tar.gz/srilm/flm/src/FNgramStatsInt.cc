/*
 * FNgramStatsUnsigned.cc --
 *	Instantiation of FNgramCounts<unsigned>
 */

#ifndef lint
static char Copyright[] = "Copyright (c) 1996, SRI International.  All Rights Reserved.";
static char RcsId[] = "@(#)$Header: /home/srilm/CVS/srilm/flm/src/FNgramStatsInt.cc,v 1.6 2006/08/11 20:47:15 stolcke Exp $";
#endif

#include "FNgramStats.cc"
#ifdef INSTANTIATE_TEMPLATES
INSTANTIATE_FNGRAMCOUNTS(FNgramCount);
#endif

